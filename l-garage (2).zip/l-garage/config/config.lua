Config = {}

-- Nastavení tvého Discord Bota
Config.Discord = {
    token = "token-bota", -- Token z Discord Developer Portálu
    guildId = "id-discord serveru"   -- ID tvého Discord serveru
}

Config.Garages = {
    {
        name = "Policejní Stanice - Hlavní",
        pedModel = `s_m_y_cop_01`,
        pedCoords = vector4(441.1, -981.1, 30.7, 90.0), -- Kde stojí ped
        spawnCoords = vector4(438.4, -984.2, 30.7, 180.0), -- Kde se objeví auto
        roles = {
            ["1472610589057613834"] = { -- ID role: STRÁŽMISTR
                { label = "Policejní Cruiser", model = "police" },
                { label = "Policejní Transportér", model = "policet" },
            },
            ["1472610589057613834"] = { -- ID role: NADSTRÁŽMISTR
                { label = "Policejní Buffalo", model = "police2" },
                { label = "Policejní Interceptor", model = "police3" },
            }
        }
    },
    {
        name = "Sheriff Garáž - Paleto",
        pedModel = `s_m_y_sheriff_01`,
        pedCoords = vector4(-445.5, 6013.2, 31.7, 45.0),
        spawnCoords = vector4(-440.2, 6010.5, 31.7, 45.0),
        roles = {
            ["1472610589057613834"] = { -- Příklad role, která má přístup i tady
                { label = "Sheriff Granger", model = "sheriff" },
            }
        }
    }
}