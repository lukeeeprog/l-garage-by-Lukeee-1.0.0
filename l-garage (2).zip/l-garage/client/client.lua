Citizen.CreateThread(function()
    for i, data in ipairs(Config.Garages) do
        -- 1. Spawn Peda
        lib.requestModel(data.pedModel)
        local ped = CreatePed(4, data.pedModel, data.pedCoords.x, data.pedCoords.y, data.pedCoords.z - 1.0, data.pedCoords.w, false, true)
        FreezeEntityPosition(ped, true)
        SetEntityInvincible(ped, true)
        SetBlockingOfNonTemporaryEvents(ped, true)

        -- 2. Vytvoření bodu interakce (využívá ox_lib points)
        local point = lib.points.new({
            coords = data.pedCoords.xyz,
            distance = 2.5,
        })

        function point:nearby()
            -- Zobrazení moderního TextUI na boku obrazovky
            lib.showTextUI('[E] Otevřít ' .. data.name, {
                position = "left-center",
                icon = 'warehouse'
            })

            if IsControlJustReleased(0, 38) then -- Klávesa E
                OpenGarageMenu(i)
            end
        end

        function point:onExit()
            lib.hideTextUI()
        end
    end
end)

function OpenGarageMenu(index)
    -- Načítání zobrazené během čekání na server
    lib.notify({title = 'Garáž', description = 'Ověřuji tvé role...', type = 'inform'})
    
    local vehicles = lib.callback.await('my_garage:getVehicles', false, index)
    
    if not vehicles or #vehicles == 0 then
        lib.notify({ title = 'Garáž', description = 'Nemáš přístup k žádným vozidlům.', type = 'error' })
        return
    end

    local options = {}
    for _, v in ipairs(vehicles) do
        table.insert(options, {
            title = v.label,
            description = 'Klikni pro vytažení vozidla',
            icon = 'car-side',
            onSelect = function()
                SpawnSelectedVehicle(v.model, Config.Garages[index].spawnCoords)
            end
        })
    end

    -- Registrace a zobrazení moderního Context Menu
    lib.registerContext({
        id = 'garage_menu_ctx',
        title = Config.Garages[index].name,
        options = options
    })
    lib.showContext('garage_menu_ctx')
end

function SpawnSelectedVehicle(model, coords)
    if not lib.requestModel(model) then 
        lib.notify({title = 'Chyba', description = 'Model vozidla neexistuje.', type = 'error'})
        return 
    end
    
    -- Vytvoření vozidla a posazení hráče dovnitř
    local veh = CreateVehicle(model, coords.x, coords.y, coords.z, coords.w, true, false)
    SetVehicleHasBeenOwnedByPlayer(veh, true)
    SetEntityAsMissionEntity(veh, true, true)
    TaskWarpPedIntoVehicle(PlayerPedId(), veh, -1)
    
    lib.notify({ title = 'Garáž', description = 'Vozidlo bylo připraveno.', type = 'success' })
end