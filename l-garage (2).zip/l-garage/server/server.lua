local function GetDiscordRoles(source)
    local discordId = nil
    for _, identifier in ipairs(GetPlayerIdentifiers(source)) do
        if string.find(identifier, "discord:") then
            discordId = string.sub(identifier, 9)
            break
        end
    end

    if not discordId then 
        print("^1[Garaz] Hrac " .. GetPlayerName(source) .. " nema propojeny Discord!^7")
        return nil 
    end

    local p = promise.new()
    -- Volání přímo na Discord API v10
    PerformHttpRequest("https://discord.com/api/v10/guilds/" .. Config.Discord.guildId .. "/members/" .. discordId, function(errorCode, resultData, headers)
        if errorCode == 200 then
            local data = json.decode(resultData)
            p:resolve(data.roles) -- Vrátí seznam ID rolí, které hráč má
        else
            print("^1[Garaz] Discord API vratilo chybu: " .. errorCode .. "^7")
            p:resolve({})
        end
    end, "GET", "", {
        ["Authorization"] = "Bot " .. Config.Discord.token,
        ["Content-Type"] = "application/json"
    })

    return Citizen.Await(p)
end

-- Callback pro klienta, aby získal povolená auta
lib.callback.register('my_garage:getVehicles', function(source, garageIndex)
    local playerRoles = GetDiscordRoles(source)
    local availableVehicles = {}
    local garage = Config.Garages[garageIndex]

    if playerRoles and garage then
        for roleId, vehicles in pairs(garage.roles) do
            for _, playerRole in ipairs(playerRoles) do
                if tostring(playerRole) == tostring(roleId) then
                    for _, v in ipairs(vehicles) do
                        table.insert(availableVehicles, v)
                    end
                end
            end
        end
    end
    return availableVehicles
end)