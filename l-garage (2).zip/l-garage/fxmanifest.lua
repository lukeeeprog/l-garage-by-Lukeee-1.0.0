fx_version 'cerulean'
game 'gta5'

author 'Lukee'
description 'Moderní Discord Standalone Garáž s více lokacemi'
version '1.0.0'

-- Důležité: ox_lib musí být načten jako první
shared_scripts {
    '@ox_lib/init.lua',
    'config.lua'
}

client_scripts {
    'client.lua'
}

server_scripts {
    'server.lua'
}